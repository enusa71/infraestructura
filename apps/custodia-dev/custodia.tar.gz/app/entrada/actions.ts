'use server';

import { auth } from '@/auth';
import { crearCustodia } from '@/lib/custodia';
import { prisma } from '@/lib/prisma';
import { z } from 'zod';

// Validar entrada
const EntradaSchema = z.object({
  contratistaCedula: z.string().min(5),
  contratistaEmpresa: z.string().optional(),
  herramientas: z.array(
    z.object({
      descripcion: z.string().min(3),
      cantidad: z.number().min(1),
    })
  ),
});

type EntradaInput = z.infer<typeof EntradaSchema>;

export async function registrarEntrada(data: EntradaInput) {
  try {
    const session = await auth();
    if (!session?.user?.email) {
      throw new Error('No autorizado');
    }

    // Validar datos
    const validado = EntradaSchema.parse(data);

    // Buscar o crear contratista
    let contratista = await prisma.contratista.findUnique({
      where: { cedula: validado.contratistaCedula },
    });

    if (!contratista) {
      contratista = await prisma.contratista.create({
        data: {
          cedula: validado.contratistaCedula,
          nombre: validado.contratistaCedula,
          empresa: validado.contratistaEmpresa,
        },
      });
    }

    // Crear custodia
    const custodia = await crearCustodia({
      contratistaId: contratista.id,
      items: validado.herramientas,
    });

    // Registrar en AuditLog
    await prisma.auditLog.create({
      data: {
        table: 'Custodia',
        action: 'CREATE',
        recordId: custodia.id,
        userId: session.user.id,
        userEmail: session.user.email,
        changes: {
          numeroConsecutivo: custodia.numeroConsecutivo,
          contratistaId: custodia.contratistaId,
          itemsCount: validado.herramientas.length,
        },
      },
    });

    return {
      success: true,
      custodiaId: custodia.id,
      numero: custodia.numeroConsecutivo,
    };
  } catch (error) {
    console.error('Error registrando entrada:', error);
    throw error;
  }
}

export async function obtenerCustodia(numero: string) {
  try {
    const session = await auth();
    if (!session?.user?.email) {
      throw new Error('No autorizado');
    }

    const custodia = await prisma.custodia.findUnique({
      where: { numeroConsecutivo: numero },
      include: {
        items: true,
        contratista: true,
        ingreso: true,
      },
    });

    if (!custodia) {
      throw new Error('Custodia no encontrada');
    }

    return custodia;
  } catch (error) {
    console.error('Error obteniendo custodia:', error);
    throw error;
  }
}

'use client';

import { useSession } from "next-auth/react";
import { useRouter } from "next/navigation";
import { useEffect, useState } from "react";
import Link from "next/link";

export default function EntradaPage() {
  const { status } = useSession();
  const router = useRouter();
  const [loading, setLoading] = useState(true);
  const [formData, setFormData] = useState({
    contratistaCedula: "",
    contratistaEmpresa: "",
    herramientas: [{ descripcion: "", cantidad: 1 }],
  });

  useEffect(() => {
    if (status === "unauthenticated") {
      router.push("/login");
    } else if (status === "authenticated") {
      setLoading(false);
    }
  }, [status, router]);

  const handleCedulaChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setFormData({ ...formData, contratistaCedula: e.target.value });
  };

  const handleEmpresaChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setFormData({ ...formData, contratistaEmpresa: e.target.value });
  };

  const handleHerramientaChange = (index: number, field: string, value: any) => {
    const nuevas = [...formData.herramientas];
    (nuevas[index] as any)[field] = value;
    setFormData({ ...formData, herramientas: nuevas });
  };

  const agregarHerramienta = () => {
    setFormData({
      ...formData,
      herramientas: [...formData.herramientas, { descripcion: "", cantidad: 1 }],
    });
  };

  const eliminarHerramienta = (index: number) => {
    setFormData({
      ...formData,
      herramientas: formData.herramientas.filter((_, i) => i !== index),
    });
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    console.log("Enviando entrada:", formData);
    alert("Entrada registrada (simulación)");
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-gray-600">Cargando...</div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow">
        <div className="max-w-4xl mx-auto px-4 py-4 flex justify-between items-center">
          <h1 className="text-2xl font-bold text-gray-900">📥 Entrada de Herramientas</h1>
          <Link href="/" className="text-blue-600 hover:text-blue-800">
            ← Volver
          </Link>
        </div>
      </header>

      {/* Form */}
      <main className="max-w-4xl mx-auto px-4 py-8">
        <form onSubmit={handleSubmit} className="bg-white rounded-lg shadow-lg p-8">
          {/* Datos del Contratista */}
          <section className="mb-8">
            <h2 className="text-xl font-bold text-gray-900 mb-4">Datos del Contratista</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Cédula (*)
                </label>
                <input
                  type="text"
                  value={formData.contratistaCedula}
                  onChange={handleCedulaChange}
                  placeholder="Ej: 123456789"
                  required
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Empresa
                </label>
                <input
                  type="text"
                  value={formData.contratistaEmpresa}
                  onChange={handleEmpresaChange}
                  placeholder="Ej: Construcciones XYZ"
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>
            </div>
          </section>

          {/* Herramientas */}
          <section className="mb-8">
            <h2 className="text-xl font-bold text-gray-900 mb-4">Herramientas y Equipos</h2>
            <div className="space-y-4">
              {formData.herramientas.map((h, index) => (
                <div key={index} className="flex gap-3 items-end">
                  <div className="flex-1">
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Descripción
                    </label>
                    <input
                      type="text"
                      value={h.descripcion}
                      onChange={(e) =>
                        handleHerramientaChange(index, "descripcion", e.target.value)
                      }
                      placeholder="Ej: Taladro, Sierra, etc."
                      required
                      className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                    />
                  </div>
                  <div className="w-24">
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Cantidad
                    </label>
                    <input
                      type="number"
                      value={h.cantidad}
                      onChange={(e) =>
                        handleHerramientaChange(index, "cantidad", parseInt(e.target.value))
                      }
                      min="1"
                      className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                    />
                  </div>
                  <button
                    type="button"
                    onClick={() => eliminarHerramienta(index)}
                    className="px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700"
                  >
                    🗑️
                  </button>
                </div>
              ))}
            </div>
            <button
              type="button"
              onClick={agregarHerramienta}
              className="mt-4 px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700"
            >
              + Agregar Herramienta
            </button>
          </section>

          {/* Buttons */}
          <div className="flex gap-4">
            <button
              type="submit"
              className="flex-1 bg-blue-600 text-white py-3 rounded-lg font-semibold hover:bg-blue-700"
            >
              ✅ Registrar Entrada
            </button>
            <Link href="/" className="flex-1 bg-gray-300 text-gray-800 py-3 rounded-lg font-semibold hover:bg-gray-400 text-center">
              Cancelar
            </Link>
          </div>
        </form>

        {/* Info */}
        <div className="mt-8 bg-blue-50 border border-blue-200 rounded-lg p-6">
          <p className="text-gray-700 text-sm">
            💡 <strong>Próximos pasos:</strong> Después de registrar, se capturarán fotos y
            firmas digitales en la siguiente pantalla.
          </p>
        </div>
      </main>
    </div>
  );
}

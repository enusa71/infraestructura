import type { Metadata } from "next";
import "./globals.css";
import { ServiceWorkerRegister } from "@/components/ServiceWorkerRegister";
import { NetworkStatus } from "@/components/NetworkStatus";

export const metadata: Metadata = {
  title: "Custodia de Herramientas - ZFB",
  description: "Control de entrada/salida de herramientas - Zona Franca Barranquilla",
  viewport: "width=device-width, initial-scale=1, maximum-scale=1",
  appleWebApp: {
    capable: true,
    statusBarStyle: "black-translucent",
    title: "Custodia",
  },
  manifest: "/manifest.json",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="es" className="h-full">
      <head>
        <link rel="manifest" href="/manifest.json" />
        <link rel="apple-touch-icon" href="/icon-192x192.png" />
        <meta name="theme-color" content="#2563eb" />
      </head>
      <body className="h-full bg-gray-50 antialiased">
        <ServiceWorkerRegister />
        <NetworkStatus />
        {children}
      </body>
    </html>
  );
}

'use client';

import { signIn } from "next-auth/react";
import { useRouter } from "next/navigation";
import { useEffect, useState } from "react";

export default function LoginPage() {
  const router = useRouter();
  const [loading, setLoading] = useState(false);

  const handleLogin = async () => {
    setLoading(true);
    await signIn("keycloak", { redirect: false });
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-blue-600 to-blue-800 p-4">
      <div className="bg-white rounded-lg shadow-xl p-8 w-full max-w-md">
        <div className="text-center mb-8">
          <h1 className="text-3xl font-bold text-gray-800 mb-2">Custodia</h1>
          <p className="text-gray-600">Control de Herramientas</p>
          <p className="text-sm text-gray-500 mt-1">Zona Franca Barranquilla</p>
        </div>

        <button
          onClick={handleLogin}
          disabled={loading}
          className="w-full bg-blue-600 hover:bg-blue-700 disabled:bg-gray-400 text-white font-semibold py-3 rounded-lg transition-colors"
        >
          {loading ? "Conectando..." : "Ingresar"}
        </button>

        <p className="text-center text-gray-600 text-sm mt-6">
          Usa tus credenciales de Zona Franca
        </p>
      </div>
    </div>
  );
}

'use client';

import { useSession } from "next-auth/react";
import { useRouter } from "next/navigation";
import { useEffect, useState } from "react";
import Link from "next/link";

export default function ReportesPage() {
  const { status } = useSession();
  const router = useRouter();
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (status === "unauthenticated") {
      router.push("/login");
    } else if (status === "authenticated") {
      setLoading(false);
    }
  }, [status, router]);

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-gray-600">Cargando...</div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow">
        <div className="max-w-4xl mx-auto px-4 py-4 flex justify-between items-center">
          <h1 className="text-2xl font-bold text-gray-900">📊 Reportes</h1>
          <Link href="/" className="text-blue-600 hover:text-blue-800">
            ← Volver
          </Link>
        </div>
      </header>

      {/* Content */}
      <main className="max-w-4xl mx-auto px-4 py-8">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
          {/* KPI: Custodias Totales */}
          <div className="bg-white rounded-lg shadow-lg p-6">
            <h3 className="text-gray-600 text-sm font-medium mb-2">Custodias Totales</h3>
            <p className="text-4xl font-bold text-gray-900">0</p>
            <p className="text-gray-500 text-sm mt-2">Todas las custodias registradas</p>
          </div>

          {/* KPI: Custodias Activas */}
          <div className="bg-white rounded-lg shadow-lg p-6">
            <h3 className="text-gray-600 text-sm font-medium mb-2">Custodias Activas</h3>
            <p className="text-4xl font-bold text-yellow-600">0</p>
            <p className="text-gray-500 text-sm mt-2">Herramientas dentro de ZFB</p>
          </div>

          {/* KPI: Custodias Cerradas */}
          <div className="bg-white rounded-lg shadow-lg p-6">
            <h3 className="text-gray-600 text-sm font-medium mb-2">Custodias Cerradas</h3>
            <p className="text-4xl font-bold text-green-600">0</p>
            <p className="text-gray-500 text-sm mt-2">Todas las herramientas retornadas</p>
          </div>

          {/* KPI: Custodias Parciales */}
          <div className="bg-white rounded-lg shadow-lg p-6">
            <h3 className="text-gray-600 text-sm font-medium mb-2">Custodias Parciales</h3>
            <p className="text-4xl font-bold text-orange-600">0</p>
            <p className="text-gray-500 text-sm mt-2">Con salida incompleta</p>
          </div>
        </div>

        {/* Filtros */}
        <div className="bg-white rounded-lg shadow-lg p-6 mb-8">
          <h2 className="text-lg font-bold text-gray-900 mb-4">Filtros</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Fecha Inicio
              </label>
              <input
                type="date"
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Fecha Fin
              </label>
              <input
                type="date"
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>
            <div className="flex items-end gap-2">
              <button className="flex-1 bg-blue-600 text-white py-2 rounded-lg font-semibold hover:bg-blue-700">
                Generar Reporte
              </button>
              <button className="px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700">
                📥 Descargar Excel
              </button>
            </div>
          </div>
        </div>

        {/* Tabla de datos (vacía) */}
        <div className="bg-white rounded-lg shadow-lg overflow-hidden">
          <table className="w-full">
            <thead className="bg-gray-100">
              <tr>
                <th className="px-6 py-4 text-left text-sm font-semibold text-gray-900">
                  Número
                </th>
                <th className="px-6 py-4 text-left text-sm font-semibold text-gray-900">
                  Contratista
                </th>
                <th className="px-6 py-4 text-left text-sm font-semibold text-gray-900">
                  Estado
                </th>
                <th className="px-6 py-4 text-left text-sm font-semibold text-gray-900">
                  Entrada
                </th>
              </tr>
            </thead>
            <tbody>
              <tr className="text-center py-8 text-gray-500">
                <td colSpan={4} className="px-6 py-8">
                  No hay datos disponibles. Los reportes aparecerán aquí cuando se registren
                  custodias.
                </td>
              </tr>
            </tbody>
          </table>
        </div>
      </main>
    </div>
  );
}

'use client';

import { useSession } from "next-auth/react";
import { useRouter } from "next/navigation";
import { useEffect, useState } from "react";
import Link from "next/link";

export default function SalidaPage() {
  const { status } = useSession();
  const router = useRouter();
  const [loading, setLoading] = useState(true);
  const [step, setStep] = useState<"busqueda" | "validacion" | "confirmacion">("busqueda");
  const [numero, setNumero] = useState("");
  const [custodia, setCustodia] = useState<any>(null);
  const [herramientasSalida, setHerramientasSalida] = useState<any[]>([]);

  useEffect(() => {
    if (status === "unauthenticated") {
      router.push("/login");
    } else if (status === "authenticated") {
      setLoading(false);
    }
  }, [status, router]);

  const handleBuscar = async (e: React.FormEvent) => {
    e.preventDefault();
    console.log("Buscando custodia:", numero);
    // Simulación de custodia encontrada
    setCustodia({
      id: "1",
      numeroConsecutivo: numero,
      contratistaId: "123",
      fechaEntrada: new Date(),
      items: [
        { id: "1", descripcion: "Taladro", cantidad: 1, fotoUrl: "/foto1.jpg" },
        { id: "2", descripcion: "Sierra", cantidad: 2, fotoUrl: "/foto2.jpg" },
      ],
    });
    setHerramientasSalida(
      custodia?.items?.map((item: any) => ({ ...item, cantidadSalida: item.cantidad })) || []
    );
    setStep("validacion");
  };

  const handleCantidadSalida = (index: number, cantidad: number) => {
    const nuevas = [...herramientasSalida];
    nuevas[index].cantidadSalida = cantidad;
    setHerramientasSalida(nuevas);
  };

  const handleConfirmarSalida = async (e: React.FormEvent) => {
    e.preventDefault();
    console.log("Confirmando salida:", herramientasSalida);
    setStep("confirmacion");
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-gray-600">Cargando...</div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow">
        <div className="max-w-4xl mx-auto px-4 py-4 flex justify-between items-center">
          <h1 className="text-2xl font-bold text-gray-900">📤 Salida de Herramientas</h1>
          <Link href="/" className="text-blue-600 hover:text-blue-800">
            ← Volver
          </Link>
        </div>
      </header>

      {/* Content */}
      <main className="max-w-4xl mx-auto px-4 py-8">
        {/* Step 1: Búsqueda */}
        {step === "busqueda" && (
          <div className="bg-white rounded-lg shadow-lg p-8">
            <h2 className="text-xl font-bold text-gray-900 mb-4">Buscar Custodia</h2>
            <form onSubmit={handleBuscar}>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Número de Custodia (*)
                </label>
                <input
                  type="text"
                  value={numero}
                  onChange={(e) => setNumero(e.target.value)}
                  placeholder="Ej: 215316"
                  required
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 mb-4"
                />
              </div>
              <button
                type="submit"
                className="w-full bg-blue-600 text-white py-3 rounded-lg font-semibold hover:bg-blue-700"
              >
                🔍 Buscar Custodia
              </button>
            </form>
          </div>
        )}

        {/* Step 2: Validación */}
        {step === "validacion" && custodia && (
          <div className="bg-white rounded-lg shadow-lg p-8">
            <h2 className="text-xl font-bold text-gray-900 mb-4">Validar Salida</h2>
            <div className="mb-6 p-4 bg-blue-50 border border-blue-200 rounded-lg">
              <p className="text-sm text-gray-700">
                <strong>Custodia:</strong> {custodia.numeroConsecutivo}
              </p>
              <p className="text-sm text-gray-700 mt-1">
                <strong>Fecha Entrada:</strong> {new Date(custodia.fechaEntrada).toLocaleString()}
              </p>
            </div>

            <form onSubmit={handleConfirmarSalida}>
              <h3 className="text-lg font-semibold text-gray-900 mb-4">
                Herramientas a Salir
              </h3>
              <div className="space-y-4 mb-6">
                {herramientasSalida.map((item, index) => (
                  <div key={index} className="border border-gray-200 rounded-lg p-4">
                    <p className="font-medium text-gray-900">{item.descripcion}</p>
                    <p className="text-sm text-gray-600 mb-3">Ingresadas: {item.cantidad}</p>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">
                        ¿Cuántas salen? (*)
                      </label>
                      <input
                        type="number"
                        min="0"
                        max={item.cantidad}
                        value={item.cantidadSalida}
                        onChange={(e) =>
                          handleCantidadSalida(index, parseInt(e.target.value) || 0)
                        }
                        className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                      />
                      {item.cantidadSalida < item.cantidad && (
                        <p className="text-sm text-orange-600 mt-2">
                          ⚠️ Salida parcial: Quedan {item.cantidad - item.cantidadSalida}{" "}
                          {item.descripcion.toLowerCase()}(s) en custodia
                        </p>
                      )}
                    </div>
                  </div>
                ))}
              </div>

              <div className="flex gap-4">
                <button
                  type="submit"
                  className="flex-1 bg-green-600 text-white py-3 rounded-lg font-semibold hover:bg-green-700"
                >
                  ✅ Confirmar Salida
                </button>
                <button
                  type="button"
                  onClick={() => setStep("busqueda")}
                  className="flex-1 bg-gray-300 text-gray-800 py-3 rounded-lg font-semibold hover:bg-gray-400"
                >
                  Cancelar
                </button>
              </div>
            </form>
          </div>
        )}

        {/* Step 3: Confirmación */}
        {step === "confirmacion" && (
          <div className="bg-white rounded-lg shadow-lg p-8 text-center">
            <div className="text-6xl mb-4">✅</div>
            <h2 className="text-2xl font-bold text-green-600 mb-2">Salida Registrada</h2>
            <p className="text-gray-700 mb-6">La salida ha sido registrada exitosamente.</p>
            <Link
              href="/"
              className="inline-block bg-blue-600 text-white px-8 py-3 rounded-lg font-semibold hover:bg-blue-700"
            >
              Volver al Inicio
            </Link>
          </div>
        )}
      </main>
    </div>
  );
}

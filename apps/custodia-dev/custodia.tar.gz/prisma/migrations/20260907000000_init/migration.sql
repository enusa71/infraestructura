-- CreateTable AuditLog
CREATE TABLE IF NOT EXISTS "AuditLog" (
    "id" TEXT NOT NULL PRIMARY KEY,
    "table" TEXT NOT NULL,
    "action" TEXT NOT NULL,
    "recordId" TEXT NOT NULL,
    "changes" JSONB NOT NULL,
    "userId" TEXT,
    "userEmail" TEXT,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP
);

-- CreateTable Contratista
CREATE TABLE IF NOT EXISTS "Contratista" (
    "id" TEXT NOT NULL PRIMARY KEY,
    "cedula" TEXT NOT NULL UNIQUE,
    "nombre" TEXT NOT NULL,
    "empresa" TEXT,
    "telefono" TEXT,
    "email" TEXT,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL
);

-- CreateTable Custodia
CREATE TABLE IF NOT EXISTS "Custodia" (
    "id" TEXT NOT NULL PRIMARY KEY,
    "numeroConsecutivo" TEXT NOT NULL UNIQUE,
    "contratistaId" TEXT NOT NULL,
    "fechaEntrada" TIMESTAMP(3) NOT NULL,
    "fechaSalida" TIMESTAMP(3),
    "estado" TEXT NOT NULL DEFAULT 'ACTIVA',
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,
    CONSTRAINT "Custodia_contratistaId_fkey" FOREIGN KEY ("contratistaId") REFERENCES "Contratista" ("id") ON DELETE RESTRICT ON UPDATE CASCADE
);

-- CreateTable CustodiaItem
CREATE TABLE IF NOT EXISTS "CustodiaItem" (
    "id" TEXT NOT NULL PRIMARY KEY,
    "custodiaId" TEXT NOT NULL,
    "descripcion" TEXT NOT NULL,
    "cantidad" INTEGER NOT NULL,
    "fotoUrl" TEXT,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,
    CONSTRAINT "CustodiaItem_custodiaId_fkey" FOREIGN KEY ("custodiaId") REFERENCES "Custodia" ("id") ON DELETE CASCADE ON UPDATE CASCADE
);

-- CreateTable CustodiaIngreso
CREATE TABLE IF NOT EXISTS "CustodiaIngreso" (
    "id" TEXT NOT NULL PRIMARY KEY,
    "custodiaId" TEXT NOT NULL UNIQUE,
    "fotoContratista" TEXT,
    "fotoGrupoHerramientas" TEXT,
    "firmaContratista" TEXT,
    "firmaGuardia" TEXT,
    "guardiaNombre" TEXT,
    "guardiaCedula" TEXT,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,
    CONSTRAINT "CustodiaIngreso_custodiaId_fkey" FOREIGN KEY ("custodiaId") REFERENCES "Custodia" ("id") ON DELETE CASCADE ON UPDATE CASCADE
);

-- CreateTable CustodiaSalida
CREATE TABLE IF NOT EXISTS "CustodiaSalida" (
    "id" TEXT NOT NULL PRIMARY KEY,
    "custodiaId" TEXT NOT NULL,
    "fechaSalida" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "cantidadSalida" INTEGER NOT NULL,
    "esParcial" BOOLEAN NOT NULL DEFAULT false,
    "fotoSalida" TEXT,
    "firmaContratista" TEXT,
    "firmaGuardia" TEXT,
    "guardiaNombre" TEXT,
    "guardiaCedula" TEXT,
    "observaciones" TEXT,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,
    CONSTRAINT "CustodiaSalida_custodiaId_fkey" FOREIGN KEY ("custodiaId") REFERENCES "Custodia" ("id") ON DELETE CASCADE ON UPDATE CASCADE
);

-- CreateIndex
CREATE INDEX "AuditLog_table_recordId_idx" ON "AuditLog"("table", "recordId");
CREATE INDEX "AuditLog_createdAt_idx" ON "AuditLog"("createdAt");
CREATE INDEX "Contratista_cedula_idx" ON "Contratista"("cedula");
CREATE INDEX "Custodia_contratistaId_idx" ON "Custodia"("contratistaId");
CREATE INDEX "Custodia_estado_idx" ON "Custodia"("estado");
CREATE INDEX "Custodia_fechaEntrada_idx" ON "Custodia"("fechaEntrada");
CREATE INDEX "CustodiaItem_custodiaId_idx" ON "CustodiaItem"("custodiaId");
CREATE INDEX "CustodiaSalida_custodiaId_idx" ON "CustodiaSalida"("custodiaId");
CREATE INDEX "CustodiaSalida_fechaSalida_idx" ON "CustodiaSalida"("fechaSalida");

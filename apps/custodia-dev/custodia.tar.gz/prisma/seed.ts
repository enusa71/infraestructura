import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();

async function main() {
  console.log('🌱 Iniciando seed de datos...');

  // Limpiar datos existentes
  await prisma.custodiaSalida.deleteMany();
  await prisma.custodiaIngreso.deleteMany();
  await prisma.custodiaItem.deleteMany();
  await prisma.custodia.deleteMany();
  await prisma.contratista.deleteMany();
  await prisma.auditLog.deleteMany();

  // Crear contratistas de ejemplo
  const contratistas = await Promise.all([
    prisma.contratista.create({
      data: {
        cedula: '1098765432',
        nombre: 'Juan Pérez García',
        empresa: 'Construcciones Pérez SAS',
        telefono: '+573001234567',
        email: 'juan@construccionesperez.com',
      },
    }),
    prisma.contratista.create({
      data: {
        cedula: '1087654321',
        nombre: 'María López Rodríguez',
        empresa: 'Servicios Técnicos López',
        telefono: '+573109876543',
        email: 'maria@servicioslopez.com',
      },
    }),
    prisma.contratista.create({
      data: {
        cedula: '1076543210',
        nombre: 'Carlos Martínez Díaz',
        empresa: 'Mantenimiento Industrial CM',
        telefono: '+573215678901',
        email: 'carlos@mantenim.com',
      },
    }),
  ]);

  console.log(`✅ ${contratistas.length} contratistas creados`);

  // Crear custodias de ejemplo
  const custodia1 = await prisma.custodia.create({
    data: {
      numeroConsecutivo: '062408001',
      contratistaId: contratistas[0].id,
      fechaEntrada: new Date('2026-09-07T08:00:00'),
      estado: 'ACTIVA',
      items: {
        create: [
          { descripcion: 'Taladro Dewalt 18V', cantidad: 1 },
          { descripcion: 'Sierra Circular Makita', cantidad: 2 },
          { descripcion: 'Nivel Láser', cantidad: 1 },
          { descripcion: 'Juego de Destornilladores', cantidad: 1 },
        ],
      },
    },
  });

  const custodia2 = await prisma.custodia.create({
    data: {
      numeroConsecutivo: '062408002',
      contratistaId: contratistas[1].id,
      fechaEntrada: new Date('2026-09-06T14:30:00'),
      fechaSalida: new Date('2026-09-07T16:45:00'),
      estado: 'CERRADA',
      items: {
        create: [
          { descripcion: 'Compresor de Aire', cantidad: 1 },
          { descripcion: 'Mangueras de Aire (50m)', cantidad: 2 },
          { descripcion: 'Pistola Neumática', cantidad: 3 },
        ],
      },
    },
  });

  const custodia3 = await prisma.custodia.create({
    data: {
      numeroConsecutivo: '062408003',
      contratistaId: contratistas[2].id,
      fechaEntrada: new Date('2026-09-05T09:15:00'),
      fechaSalida: new Date('2026-09-07T10:30:00'),
      estado: 'PARCIAL',
      items: {
        create: [
          { descripcion: 'Multímetro Digital', cantidad: 1 },
          { descripcion: 'Juego de Herramientas Eléctricas', cantidad: 2 },
          { descripcion: 'Cableado Cat6', cantidad: 3 },
        ],
      },
    },
  });

  console.log(`✅ 3 custodias creadas (1 ACTIVA, 1 CERRADA, 1 PARCIAL)`);

  // Crear ingresos
  await prisma.custodiaIngreso.create({
    data: {
      custodiaId: custodia1.id,
      guardiaNombre: 'Jorge Chávarro',
      guardiaCedula: '1055555555',
    },
  });

  await prisma.custodiaIngreso.create({
    data: {
      custodiaId: custodia2.id,
      guardiaNombre: 'Jorge Chávarro',
      guardiaCedula: '1055555555',
    },
  });

  console.log(`✅ Ingresos registrados`);

  // Crear salidas
  await prisma.custodiaSalida.create({
    data: {
      custodiaId: custodia2.id,
      cantidadSalida: 6,
      esParcial: false,
      guardiaNombre: 'João Andebossi',
      guardiaCedula: '1044444444',
    },
  });

  await prisma.custodiaSalida.create({
    data: {
      custodiaId: custodia3.id,
      cantidadSalida: 2,
      esParcial: true,
      guardiaNombre: 'João Andebossi',
      guardiaCedula: '1044444444',
      observaciones: 'Contratista dejó 1 juego de herramientas en custodia',
    },
  });

  console.log(`✅ Salidas registradas`);

  // Crear audit logs
  await prisma.auditLog.create({
    data: {
      table: 'Custodia',
      action: 'CREATE',
      recordId: custodia1.id,
      userId: 'seed-script',
      userEmail: 'seed@custodia.local',
      changes: { numeroConsecutivo: custodia1.numeroConsecutivo },
    },
  });

  console.log(`✅ Audit logs creados`);
  console.log('🎉 Seed completado exitosamente');
}

main()
  .catch((e) => {
    console.error('❌ Error en seed:', e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
